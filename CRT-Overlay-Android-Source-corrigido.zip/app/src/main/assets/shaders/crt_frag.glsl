precision mediump float;
varying vec2 v_TexCoord;
uniform float u_Time;
uniform float u_Curvature;
uniform float u_ScanlineIntensity;
uniform float u_ScanlineCount;
uniform float u_Opacity;

vec2 curve(vec2 uv) {
    if (u_Curvature <= 0.001) return uv;
    vec2 coord = uv * 2.0 - 1.0;
    vec2 offset = coord.yx / (3.2 / u_Curvature);
    coord = coord + coord * offset * offset;
    return coord * 0.5 + 0.5;
}

void main() {
    vec2 uv = curve(v_TexCoord);
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
        gl_FragColor = vec4(0.0, 0.0, 0.0, 0.8 * u_Opacity);
        return;
    }

    // Scanlines
    float scanline = sin(uv.y * u_ScanlineCount * 3.14159265);
    scanline = (scanline + 1.0) * 0.5;
    float dark = mix(1.0, scanline, u_ScanlineIntensity);

    // Vignette
    vec2 vuv = uv * (1.0 - uv);
    float vig = vuv.x * vuv.y * 15.0;
    vig = clamp(pow(vig, 0.4), 0.0, 1.0);

    // Transparent overlay tint with scanlines
    float alpha = (1.0 - dark * vig) * u_Opacity;
    gl_FragColor = vec4(0.0, 0.0, 0.0, clamp(alpha, 0.0, 0.9));
}
