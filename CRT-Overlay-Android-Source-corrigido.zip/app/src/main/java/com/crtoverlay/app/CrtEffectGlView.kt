package com.crtoverlay.app

import android.content.Context
import android.graphics.PixelFormat
import android.opengl.GLSurfaceView

class CrtEffectGlView(context: Context) : GLSurfaceView(context) {

    init {
        setEGLContextClientVersion(2)
        setZOrderOnTop(true)
        holder.setFormat(PixelFormat.TRANSLUCENT)
        setRenderer(CrtGlRenderer(context))
        renderMode = RENDERMODE_CONTINUOUSLY
    }
}
