# CRT Overlay (Android)

Aplica um efeito de tubo CRT (scanlines, vinheta, curvatura) sobre toda a tela, **sem bloquear os toques** nos outros apps.

## Uso
1. Abra o app e toque em **ATIVAR CRT** (na primeira vez, conceda "Sobrepor a outros apps").
2. Uma bolinha **CRT** flutuante aparece. Toque nela para abrir os controles:
   - Intensidade, densidade das linhas e curvatura (ao vivo)
   - Ligar/desligar o efeito
   - Parar e fechar
3. Arraste a bolinha ou o cabeçalho do painel para movê-lo.
4. Também dá para parar pela notificação ("Parar").

## Compilar
Suba o projeto no GitHub; a aba **Actions** gera o APK (artefato `CRT-Overlay-Android-APK`).
