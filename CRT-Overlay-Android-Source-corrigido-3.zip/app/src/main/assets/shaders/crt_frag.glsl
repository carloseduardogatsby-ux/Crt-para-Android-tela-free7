precision mediump float;
varying vec2 v_TexCoord;
uniform float u_Time;
uniform float u_Curvature;
uniform float u_ScanlineIntensity;
uniform float u_ScanlineCount;
uniform float u_Opacity;

vec2 curve(vec2 uv) {
    vec2 coord = uv * 2.0 - 1.0;
    vec2 offset = coord.yx * u_Curvature * 0.3;
    coord = coord + coord * offset * offset;
    return coord * 0.5 + 0.5;
}

void main() {
    vec2 uv = curve(v_TexCoord);
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
        gl_FragColor = vec4(0.0, 0.0, 0.0, 0.7);
        return;
    }

    // Scanlines: linhas escuras finas (0 = sem linha, 1 = linha cheia)
    float line = 0.5 - 0.5 * sin(uv.y * u_ScanlineCount * 3.14159265);
    float scanAlpha = line * u_ScanlineIntensity * 0.5;

    // Vinheta suave: escurece só as bordas
    vec2 vuv = uv * (1.0 - uv);
    float vig = clamp(pow(vuv.x * vuv.y * 15.0, 0.25), 0.0, 1.0);
    float vigAlpha = (1.0 - vig) * 0.5 * u_Opacity;

    float alpha = clamp(scanAlpha + vigAlpha, 0.0, 0.8);
    gl_FragColor = vec4(0.0, 0.0, 0.0, alpha);
}
