attribute vec4 a_Position;
varying vec2 v_TexCoord;

void main() {
    gl_Position = a_Position;
    v_TexCoord = (a_Position.xy + 1.0) * 0.5;
}
