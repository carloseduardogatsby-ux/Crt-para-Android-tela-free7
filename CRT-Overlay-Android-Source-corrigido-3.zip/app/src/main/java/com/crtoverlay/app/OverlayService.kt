package com.crtoverlay.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        var isRunning = false
        const val ACTION_STOP = "com.crtoverlay.app.STOP"
    }

    private var windowManager: WindowManager? = null
    private var crtView: CrtEffectGlView? = null
    private var controlRoot: LinearLayout? = null
    private var controlParams: WindowManager.LayoutParams? = null
    private var effectOn = true

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        crtView?.requestRender()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        startForegroundNotification()

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        getSharedPreferences("crt", MODE_PRIVATE)
            .registerOnSharedPreferenceChangeListener(prefsListener)

        try {
            addCrtLayer()
            addControlPanel()
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    // Camada do efeito CRT: cobre a tela toda e deixa os toques passarem
    private fun addCrtLayer() {
        crtView = CrtEffectGlView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Android 12+ bloqueia toques que atravessam janelas com alpha > 0.8
            alpha = 0.79f
        }
        windowManager?.addView(crtView, params)
    }

    // Painel flutuante: bolinha "CRT" que expande em controles
    private fun addControlPanel() {
        val prefs = getSharedPreferences("crt", MODE_PRIVATE)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        controlRoot = root

        val bubble = TextView(this).apply {
            text = "CRT"
            setTextColor(Color.BLACK)
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(0xFF10B981.toInt(), 26)
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(14))
            background = rounded(0xF0090D16.toInt(), 16)
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(dp(250), ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        // Cabeçalho (arraste por aqui) + botão de minimizar
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "☰ CRT (arraste)"
            setTextColor(0xFF10B981.toInt())
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f)
            gravity = Gravity.CENTER_VERTICAL
        }
        val minimize = TextView(this).apply {
            text = "—"
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(36))
        }
        header.addView(title)
        header.addView(minimize)
        panel.addView(header)

        addSlider(panel, "Intensidade", "intensity", 40, prefs)
        addSlider(panel, "Densidade das linhas", "density", 50, prefs)
        addSlider(panel, "Curvatura", "curve", 15, prefs)

        val toggle = Button(this).apply {
            text = "EFEITO: LIGADO"
            textSize = 12f
            setTextColor(Color.BLACK)
            setBackgroundColor(0xFF10B981.toInt())
        }
        toggle.setOnClickListener {
            effectOn = !effectOn
            crtView?.visibility = if (effectOn) View.VISIBLE else View.GONE
            toggle.text = if (effectOn) "EFEITO: LIGADO" else "EFEITO: DESLIGADO"
            toggle.setBackgroundColor(
                if (effectOn) 0xFF10B981.toInt() else 0xFF64748B.toInt()
            )
        }
        val toggleLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }
        panel.addView(toggle, toggleLp)

        val stop = Button(this).apply {
            text = "PARAR E FECHAR"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFFE11D48.toInt())
        }
        stop.setOnClickListener { stopSelf() }
        val stopLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) }
        panel.addView(stop, stopLp)

        root.addView(bubble)
        root.addView(panel)

        val params = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(140)
        }
        controlParams = params

        attachDrag(bubble) {
            bubble.visibility = View.GONE
            panel.visibility = View.VISIBLE
        }
        attachDrag(title, null)
        minimize.setOnClickListener {
            panel.visibility = View.GONE
            bubble.visibility = View.VISIBLE
        }

        windowManager?.addView(root, params)
    }

    private fun addSlider(
        parent: LinearLayout,
        label: String,
        key: String,
        default: Int,
        prefs: SharedPreferences
    ) {
        val current = prefs.getInt(key, default)
        val tv = TextView(this).apply {
            text = "$label: $current"
            setTextColor(0xFF94A3B8.toInt())
            textSize = 12f
            setPadding(0, dp(8), 0, 0)
        }
        val sb = SeekBar(this).apply {
            max = 100
            progress = current
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                    prefs.edit().putInt(key, value).apply()
                    tv.text = "$label: $value"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        parent.addView(tv)
        parent.addView(sb)
    }

    // Arrastar o painel; toque curto (sem arrastar) chama onTap
    private fun attachDrag(handle: View, onTap: (() -> Unit)?) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        handle.setOnTouchListener { _, e ->
            val p = controlParams
            if (p == null) {
                false
            } else {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = p.x
                        startY = p.y
                        touchX = e.rawX
                        touchY = e.rawY
                        moved = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - touchX).toInt()
                        val dy = (e.rawY - touchY).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            p.x = startX + dx
                            p.y = startY + dy
                            windowManager?.updateViewLayout(controlRoot, p)
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) onTap?.invoke()
                        true
                    }
                    else -> false
                }
            }
        }
    }

    private fun startForegroundNotification() {
        val channelId = "crt_overlay_service_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Sobreposição CRT",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("CRT Overlay Ativo")
            .setContentText("Toque na bolinha CRT para ajustar o efeito")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Parar", stopIntent)
            .setOngoing(true)
            .build()

        startForeground(1001, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        getSharedPreferences("crt", MODE_PRIVATE)
            .unregisterOnSharedPreferenceChangeListener(prefsListener)
        try { controlRoot?.let { windowManager?.removeView(it) } } catch (e: Exception) {}
        try { crtView?.let { windowManager?.removeView(it) } } catch (e: Exception) {}
        controlRoot = null
        crtView = null
    }
}
