package com.crtoverlay.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1
            )
        }

        val btnToggle = findViewById<Button>(R.id.btn_toggle_overlay)
        val textStatus = findViewById<TextView>(R.id.text_status)

        updateButtonState(btnToggle, textStatus)

        val prefs = getSharedPreferences("crt", MODE_PRIVATE)
        val seek = findViewById<SeekBar>(R.id.seek_intensity)
        seek.progress = prefs.getInt("intensity", 40)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                prefs.edit().putInt("intensity", value).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        btnToggle.setOnClickListener {
            if (!checkOverlayPermission()) {
                requestOverlayPermission()
            } else {
                if (OverlayService.isRunning) {
                    stopService(Intent(this, OverlayService::class.java))
                    Toast.makeText(this, "Efeito CRT desativado da tela", Toast.LENGTH_SHORT).show()
                } else {
                    val intent = Intent(this, OverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(intent)
                    } else {
                        startService(intent)
                    }
                    Toast.makeText(this, "CRT Ativado! Abra o YouTube para ver o efeito.", Toast.LENGTH_LONG).show()
                }
                updateButtonState(btnToggle, textStatus)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val btnToggle = findViewById<Button>(R.id.btn_toggle_overlay)
        val textStatus = findViewById<TextView>(R.id.text_status)
        updateButtonState(btnToggle, textStatus)
    }

    private fun updateButtonState(btn: Button, status: TextView) {
        if (OverlayService.isRunning) {
            btn.text = "■ DESATIVAR SOBREPOSIÇÃO CRT"
            btn.setBackgroundColor(0xFFE11D48.toInt()) // Rose
            status.text = "Status: CRT ATIVO SOBRE O YOUTUBE E APPS"
            status.setTextColor(0xFF10B981.toInt()) // Emerald
        } else {
            btn.text = "▶ ATIVAR CRT SOBRE O YOUTUBE E APPS"
            btn.setBackgroundColor(0xFF10B981.toInt()) // Emerald
            status.text = "Status: Desativado"
            status.setTextColor(0xFF94A3B8.toInt()) // Slate
        }
    }

    private fun checkOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(
                this,
                "Ative a permissão 'Aparecer sobre outros apps' para o CRT cobrir o YouTube",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
