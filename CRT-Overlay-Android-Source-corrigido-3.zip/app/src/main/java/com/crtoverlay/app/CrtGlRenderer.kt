package com.crtoverlay.app

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class CrtGlRenderer(private val context: Context) : GLSurfaceView.Renderer {

    private var program: Int = 0
    private var uTimeLoc: Int = 0
    private var uCurvatureLoc: Int = 0
    private var uScanlineLoc: Int = 0
    private var uScanlineCountLoc: Int = 0
    private var uOpacityLoc: Int = 0

    private val quadVertices = floatArrayOf(
        -1.0f, -1.0f,
         1.0f, -1.0f,
        -1.0f,  1.0f,
         1.0f,  1.0f
    )

    private val vertexBuffer: FloatBuffer = ByteBuffer.allocateDirect(quadVertices.size * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .apply {
            put(quadVertices)
            position(0)
        }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        val vSrc = context.assets.open("shaders/crt_vert.glsl").bufferedReader().use { it.readText() }
        val fSrc = context.assets.open("shaders/crt_frag.glsl").bufferedReader().use { it.readText() }

        val vs = GLES20.glCreateShader(GLES20.GL_VERTEX_SHADER).also {
            GLES20.glShaderSource(it, vSrc)
            GLES20.glCompileShader(it)
        }
        val fs = GLES20.glCreateShader(GLES20.GL_FRAGMENT_SHADER).also {
            GLES20.glShaderSource(it, fSrc)
            GLES20.glCompileShader(it)
        }

        program = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, vs)
            GLES20.glAttachShader(it, fs)
            GLES20.glLinkProgram(it)
        }

        uTimeLoc = GLES20.glGetUniformLocation(program, "u_Time")
        uCurvatureLoc = GLES20.glGetUniformLocation(program, "u_Curvature")
        uScanlineLoc = GLES20.glGetUniformLocation(program, "u_ScanlineIntensity")
        uScanlineCountLoc = GLES20.glGetUniformLocation(program, "u_ScanlineCount")
        uOpacityLoc = GLES20.glGetUniformLocation(program, "u_Opacity")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glUseProgram(program)

        val prefs = context.getSharedPreferences("crt", Context.MODE_PRIVATE)
        val level = prefs.getInt("intensity", 40) / 100f
        val lineCount = 200f + prefs.getInt("density", 50) * 6f
        val curve = prefs.getInt("curve", 15) / 100f

        GLES20.glUniform1f(uCurvatureLoc, curve)
        GLES20.glUniform1f(uScanlineLoc, level)
        GLES20.glUniform1f(uScanlineCountLoc, lineCount)
        GLES20.glUniform1f(uOpacityLoc, level)

        val aPos = GLES20.glGetAttribLocation(program, "a_Position")
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, vertexBuffer)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos)
    }
}
